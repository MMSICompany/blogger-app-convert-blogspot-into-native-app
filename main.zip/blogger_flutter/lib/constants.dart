import 'package:flutter/material.dart';

//TODO: Edit these values;
//BLogspot url (please include like in reference)
const String kBlogUrl = 'https://www.arlinadzgn.com/';
//Google Console api key
const String kApiKey = 'AIzaSyBxKWHerHdUqpu4boo4pmAfxla5vH1X5bg';
//Material Color Theme
const Color kAppColor = Colors.red;
//App title
const String kAppTitle = 'Blogger';
//Admob app id
const String kAdmobAppId = 'ca-app-pub-3940256099942544~3347511713';
//Admob banner id
const String kAdmobBannerId = 'ca-app-pub-3940256099942544/6300978111';
